function checkPassword(){
	var pw1=joinForm.user_pwd.value;
	var pw2=joinForm.user_repwd.value;
	if(pw1!==pw2){
		alert("두 비번이 일치하지 않습니다.");
		joinForm.user_pwd.value="";
		joinForm.user_repwd.value="";
	}else{
		joinForm.submit();//submit버튼을 클릭한것과 동일하게 작동
	}
	
}